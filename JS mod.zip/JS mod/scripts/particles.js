const blue = extend(ParticleEffect, {
    particles: 20,
    length: 16,
    lifetime: 18,
    sizeFrom: 4,
    sizeTo: 0,
    cone: 360,
    colorFrom: Color.valueOf("2e74ff"),
    colorTo: Color.valueOf("b0e1ff"),
    region: "jsm-ro",
    spin: 40, 
    });



const trail = extend(ParticleEffect, {});

trail.particles = 1;
trail.length = 0;
trail.lifetime = 40;
trail.sizeFrom = 6;
trail.sizeTo = 0;
trail.colorFrom = Color.valueOf("00377d80");
trail.colorTo = Color.valueOf("000a2e80");



const massr = extend(ParticleEffect, {
    particles: 10,
    length: 24,
    lifetime: 30,
    sizeFrom: 5,
    sizeTo: 0,
    cone: 360,
    colorFrom: Color.valueOf("00f06959"),
    colorTo: Color.valueOf("00ff931a"),
    });



const massS = extend(ParticleEffect, {
    particles: 15,
    length: 24,
    lifetime: 30,
    sizeFrom: 6,
    sizeTo: 0,
    cone: 360,
    colorFrom: Color.valueOf("ffa80080"),
    colorTo: Color.valueOf("00f06959"),
    });



const GB = extend(ExplosionEffect, {

  smokeColor: Color.valueOf("00a14b"),
  sparkColor: Color.valueOf("00ff77"),
  waveColor: Color.valueOf("30e35c"),
  waveStroke: 2,
  waveRad: 40,
  lifetime: 40,
  });

module.exports = {
   massr: massr,
   massS: massS,
   blue: blue,
   trail: trail,
   GB: GB,
}